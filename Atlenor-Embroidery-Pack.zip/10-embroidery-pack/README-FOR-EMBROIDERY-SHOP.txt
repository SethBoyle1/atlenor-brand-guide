ATLENOR LOGO EMBROIDERY PACK
============================

Start with Atlenor-Embroidery-Spec.pdf. It has the placements, finished sizes,
thread colors and digitizing notes.

FOLDERS
  artwork/     SVG vector art at exact finished size. Digitize from these.
               Letters are on layer "thread-A-letters".
               The ring and star are on layer "thread-B-ring-and-star".
  pdf/         The same art as vector PDFs at exact finished size.
               (White art looks blank on a white screen. That is expected.)
  png-300dpi/  Transparent 300 dpi PNGs, for reference only.
  reference/   Placement drawings.

FILE NAMES
  atlenor-emb-[placement]-[width]-[version]
  Versions:
    two-thread-dark-garments   white letters + metallic silver ring and star
    one-thread-white           all white, for dark garments
    one-thread-black           all black (#000000), for light garments

THREADS (match from your stock)
  A  White
  B  Metallic silver (close to Pantone 877 C)
     Black #000000 (your standard black thread) for light garments

PLEASE
  - Keep the gap at the top of the ring open. It is part of the logo.
  - Use the file made for each size. Don't scale one file to every size.
  - Send a sew-out photo on the actual garment for approval before production.

The Atlenor(TM) name and logo are trademarks of Atlenor, LLC.
Use this art only for the order it was supplied for.
