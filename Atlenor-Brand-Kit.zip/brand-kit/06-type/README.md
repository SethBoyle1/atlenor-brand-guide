# Atlenor type

**Geist** for headings and text, and **Geist Mono** for numbers, data, labels and timestamps.

- Both are free and open source (SIL Open Font License), so they can be used on the website, in apps and in print.
- Download from Google Fonts: https://fonts.google.com/specimen/Geist and https://fonts.google.com/specimen/Geist+Mono
- Web: `<link href="https://fonts.googleapis.com/css2?family=Geist:wght@300;400;500;600;700&family=Geist+Mono:wght@400;500&display=swap" rel="stylesheet">`

| Use | Font | Weight | Notes |
|---|---|---|---|
| Headlines | Geist | Semibold 600 | Tight letter spacing (−2%) |
| Subheads | Geist | Medium 500 | |
| Body | Geist | Regular 400 | Short sentences |
| Numbers and data | Geist Mono | Regular 400 / Medium 500 | Tabular figures |
| Fallback | Helvetica or Arial | | Email, Word and PowerPoint when Geist isn't installed |

The ATLENOR letters in the logo are custom drawn. Never type the name in a font and use it as the logo.
