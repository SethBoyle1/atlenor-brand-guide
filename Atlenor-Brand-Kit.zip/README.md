# Atlenor brand kit

Open **Atlenor-Brand-Guide.html** in a browser, or **Atlenor-Brand-Guide.pdf**. The guide explains every file in this kit.

| Folder | What's in it |
|---|---|
| `01-logo/` | Every finish (mirror chrome = main, straight chrome, pure chrome, baby blue, one color), for dark and light backgrounds, as SVG and PNG |
| `02-real-light-images/` | The signature chrome logo with real starlight: website hero, phone, link preview, mark |
| `03-star-breakthrough-effect/` | The star breaking up through the O: stills, vector marks, logo intro video and GIF |
| `04-app-and-icons/` | iOS and Android icon sets, launch screens, favicons, web manifest |
| `05-color/` | Color codes: CSS, JSON, and text with RGB and CMYK |
| `06-type/` | Geist and Geist Mono |
| `07-templates/` | Social banners, video-call background, slides, business card and letterhead PDFs, email signature |
| `08-placement-mockups/` | App, website, cards, stationery, signs, social, slides, merch, vehicle |
| `09-apparel-mockups/` | Tees, polos, hoodies, quarter-zip, caps, beanie, embroidery close-up |
| `10-embroidery-pack/` | Everything an embroidery shop needs. Also zipped: `Atlenor-Embroidery-Pack.zip` |

- **Send to an embroidery shop:** `Atlenor-Embroidery-Pack.zip`
- **Send to a designer, printer or developer:** `Atlenor-Brand-Kit.zip`

Use ™, never ®, until the trademark registers. Have trademark counsel review the logo before filing or large print runs.
Sources and build scripts live in `../logo-redesign/_build/` (not part of the shareable kit).

**Colors (November 20, 2026):** black background, mirror chrome logo, and baby blue (#8EC9F2) as the only accent. Gold and night navy were retired so the kit matches atlenor.com.
